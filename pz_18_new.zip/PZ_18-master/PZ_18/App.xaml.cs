﻿using System.Windows;

namespace PZ_18
{
	public partial class App : Application
	{
	}
}
